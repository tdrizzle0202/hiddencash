# Apple Standard End User License Agreement (EULA)

This End User License Agreement (“EULA”) is between you and HiddenCash, not Apple Inc. (“Apple”). Apple is not a party to this EULA.

## Scope of License
HiddenCash grants you a non-transferable license to use the HiddenCash application on any Apple-branded products that you own or control and as permitted by the App Store Terms of Service.

## Maintenance and Support
HiddenCash is solely responsible for providing maintenance and support services for the application. Apple has no obligation to furnish any maintenance or support services.

## Warranty
The application is provided “AS IS” without warranty of any kind. To the maximum extent permitted by applicable law, HiddenCash disclaims all warranties.

## Product Claims
HiddenCash, not Apple, is responsible for addressing any claims relating to the application.

## Intellectual Property Rights
HiddenCash, not Apple, will be solely responsible for investigation, defense, settlement, and discharge of any intellectual property infringement claim.

## Legal Compliance
You represent and warrant that you are not located in a country subject to a U.S. Government embargo.

## Developer Contact
HiddenCash  
Email: tbhapp1234@gmail.com
